'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _keyboard_accessible = require('./keyboard_accessible');

Object.defineProperty(exports, 'KuiKeyboardAccessible', {
  enumerable: true,
  get: function get() {
    return _keyboard_accessible.KuiKeyboardAccessible;
  }
});
